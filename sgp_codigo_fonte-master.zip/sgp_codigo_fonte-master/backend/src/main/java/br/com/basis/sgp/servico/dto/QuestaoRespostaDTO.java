package br.com.basis.sgp.servico.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QuestaoRespostaDTO {

    private Long id;
    private Long resposta;
}
