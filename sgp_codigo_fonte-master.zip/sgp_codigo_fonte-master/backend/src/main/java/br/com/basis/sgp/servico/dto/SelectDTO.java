package br.com.basis.sgp.servico.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SelectDTO {

    private Long value;
    private String label;

}
