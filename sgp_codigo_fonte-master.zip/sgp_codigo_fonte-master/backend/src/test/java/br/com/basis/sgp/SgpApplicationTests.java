package br.com.basis.sgp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgpApplicationTests {

    @Test
    void contextLoads() {
    }

}
