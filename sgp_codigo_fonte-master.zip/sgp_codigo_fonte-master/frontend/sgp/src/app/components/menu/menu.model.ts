export class MenuModel {
  descricao: string;
  path: string;
  permissao: boolean;
}
