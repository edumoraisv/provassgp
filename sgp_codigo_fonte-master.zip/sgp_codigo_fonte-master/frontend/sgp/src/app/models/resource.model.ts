export class Resource {
  id: number;
}
