import { Resource } from 'src/app/models/resource.model';

export class Senioridade extends Resource {
  descricao: string;
}
