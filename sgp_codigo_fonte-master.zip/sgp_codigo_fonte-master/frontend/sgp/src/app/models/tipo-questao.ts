import { Resource } from './resource.model';

export class TipoQuestao extends Resource {
  descricao: string;
}
