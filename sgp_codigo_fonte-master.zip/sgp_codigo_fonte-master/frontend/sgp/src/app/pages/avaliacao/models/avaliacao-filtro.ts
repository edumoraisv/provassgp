export class FiltroAvaliacao {
  id: number;
  nomeCandidato: string;
  tituloProva: string;
  data: Date;
  aproveitamento: number;
}
