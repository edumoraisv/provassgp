export class AvaliacaoPreenchida {
  id: number;
  idProva: number;
  respostas: number[] = [];
}
