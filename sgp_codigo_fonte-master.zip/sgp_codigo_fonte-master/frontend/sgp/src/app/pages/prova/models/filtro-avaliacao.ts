export class FiltroAvaliacao {
  id: string;
  candidato: string;
  idCandidato: number;
  titulo: string;
  aproveitamento: number;
  situacao: string;
}
