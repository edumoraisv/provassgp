export class FiltroProva {
  id: number;
  titulo: string;
  percentual: number;
}
