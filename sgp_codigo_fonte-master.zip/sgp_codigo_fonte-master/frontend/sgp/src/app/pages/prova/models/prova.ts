import { SelectItem } from 'primeng';
export class Prova {
  id: number;
  titulo: string;
  percentual: number;
  questoes: SelectItem[];
}
