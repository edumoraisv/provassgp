export class QuestaoFiltro {
  id: number;
  descricao: string;
  senioridade: number;
  tipoQuestao: number;

}
