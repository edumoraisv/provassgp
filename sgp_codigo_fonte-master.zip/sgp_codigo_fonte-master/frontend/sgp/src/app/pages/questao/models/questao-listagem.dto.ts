export class QuestaoListagemDTO {
  id: number;
  descricao: string;
  descricaoSenioridade: string;
  descricaoTipo: string;
}
