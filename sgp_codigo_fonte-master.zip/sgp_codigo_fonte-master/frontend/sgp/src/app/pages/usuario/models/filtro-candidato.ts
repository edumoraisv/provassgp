export class FiltroCandidato {
  id: number;
  nome: string;
  email: string;
}
