import { Usuario } from './usuario';

export class UsuarioToken extends Usuario {
  token: string;
}
