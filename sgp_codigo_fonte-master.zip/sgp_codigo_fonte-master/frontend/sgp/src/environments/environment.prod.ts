export const environment = {
  production: true,
  key: 'br.com.basis.sgp'
};
